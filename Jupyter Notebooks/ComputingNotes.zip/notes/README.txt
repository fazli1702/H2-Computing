AUTHOR:
MOHAMED FAZLI B MOHD YAZID
YIJC 19S15

Summary:
1) Data Representations (binary, hexadecimal ..)

2) Sorting algorithms
 -- bubble sort
 -- insertion sort
 -- selection sort (not in syllabus)
 -- merge sort
 -- quick sort

3) Search algorithms
 -- hash table
 -- binary search

4) Data Structures (OOP)
 -- Stack
 -- Queue
 -- Linked List (normal/array implementation)
 -- Binary Tree (normal/array implementation)
